package com.example.android.footballscorekeeper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.android.footballscorekeeper.R;

public class MainActivity extends AppCompatActivity {
    int scoreTeamA = 0;
    int FoulsA = 0 ;
    int OutsA = 0 ;
    int scoreTeamB = 0;
    int FoulsB = 0 ;
    int OutsB = 0 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    /**
     * Increase the score for Team A by 1 point.
     */
    public void GoalA(View v) {
        scoreTeamA = scoreTeamA + 1;
        displayForTeamA(scoreTeamA);
    }

    /**
     * Increase the fouls for Team A
     */
    public void FoulsA(View v) {
        FoulsA = FoulsA + 1;
        displayTeamAFouls(FoulsA);
    }

    /**
     * Increase the outs for Team A
     */
    public void OutsA(View v) {
        OutsA = OutsA + 1;
        displayTeamAOuts(OutsA);
    }

    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }
    /**
     * Displays the fouls for Team A.
     */
    public void displayTeamAFouls(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_fouls);
        scoreView.setText(String.valueOf(score));
    }
    /**
     * Displays the outs for Team A.
     */
    public void displayTeamAOuts(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_outs);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Increase the score for Team B by 1 point.
     */
    public void GoalB(View v) {
        scoreTeamB = scoreTeamB + 1;
        displayForTeamB(scoreTeamB);
    }

    /**
     * Increase the fouls for Team B
     */
    public void FoulB(View v) {
        FoulsB = FoulsB + 1;
        displayTeamBFouls(FoulsB);
    }

    /**
     * Increase the outs for Team B
     */
    public void OutsB(View v) {
       OutsB = OutsB + 1;
        displayTeamBOuts(OutsB);
    }

    /**
     * Displays the given score for Team B.
     */
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }
    /**
     * Displays the fouls for Team B.
     */
    public void displayTeamBFouls(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_fouls);
        scoreView.setText(String.valueOf(score));
    }
    /**
     * Displays the outs for Team B.
     */
    public void displayTeamBOuts(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_outs);
        scoreView.setText(String.valueOf(score));
    }

    public void resetScore(View v) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        FoulsA = 0;
        OutsA = 0 ;
        FoulsB = 0;
        OutsB = 0 ;
        displayForTeamA(scoreTeamA);
        displayTeamAFouls(FoulsA);
        displayTeamAOuts(OutsA);
        displayForTeamB(scoreTeamB);
        displayTeamBFouls(FoulsB);
        displayTeamBOuts(OutsB);
    }
}